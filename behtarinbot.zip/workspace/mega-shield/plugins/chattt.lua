local function run(msg, matches)
if matches[1] == "بای" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'بای','خدافز','خدانگهدار','برو دیگگههه😒','ای دون برو به سلامت','بابای عشقم','خدافز به بابا هم سلام برسون','بای بای','bb azizam'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "خدافظ" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'بای','خدافز','خدانگهدار','برو دیگگههه😒','ای دون برو به سلامت','بابای عشقم','خدافز به بابا هم سلام برسون','بای بای','bb azizam'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "خوبی؟" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'ممنون','تشکر','به خوبی شما','عالی','مرسی نفسم','مرسی عشقم','من خوبم.خانواده خوبن؟','مرسی اه','khobam❤️'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "خوبی" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'ممنون','تشکر','به خوبی شما','عالی','مرسی نفسم','مرسی عشقم','من خوبم.خانواده خوبن؟','مرسی اه','khobam❤️'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "خوبین" then
      if msg.to.type == 'channel' then
            local answers = {'ممنون','تشکر','به خوبی شما','عالی','مرسی نفسم','مرسی عشقم','من خوبم.خانواده خوبن؟','مرسی اه','khobam❤️'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😐" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'😐عجب','😐خخخ بسه','مرگ من بسه','جون عمت نفرست','نفرست اههه','پوووووف','داری روانیم میکنیاااا','مرسی اه','نفرست دیگ بسه ','هه هه مسخره همش پوکر میده','بفرست تا جونت در بیاد','الان که چی پوکر میدی','خیلی زیاد میفرستی','وای تو شاه پوکری که '}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "شب بخیر" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'همچنین','تشکر','مرسی ممنون','شب بخیر','شب خوبی داشته باشید','شب خوبی برای شما ارزومندم','خدانگهدار گرامی','یاعلی برادر','#GN'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "اصل" then
     if msg.to.type == 'channel' or 'chat' then
            local answers = {'اصل چیه؟','برای چیته آخه','به من رحم کن 😖','پووووووف اصل برای چیته','هوووووم','چی بگم','من رباتم و دارم چیزای زیادی یاد میگیرم.قول بده اذیتم نکنی چون اذیتت میکنماااا😶😁','اصررا نکن اصل نمیدم','نمیدم'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == 'سلام' then
			if msg.to.type == 'channel' or 'chat' then
            local answers = {'سلام خوبی؟','سلام عشقم','سلام','سلام جیگر گروه','سلام گلم','چند بار سلام میکنی','سلام خخخخ','😐سلام','سهلام 😐😐','درود دوست عزیز'}
            return answers[math.random(#answers)]
			end
	  end
	  if matches[1] == "ربات" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'جوووووون عشقم','اینقدر منو صدا نزن','اذیتم نکن همش','چیزی میخوای از من؟','بگو دیگه عه','بلهههه؟','منو صدا میزنی خوشکلم؟','واییی جون دلم🙈','جججوووونن عشقم❤️'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😍" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'واهاییی','عاشقتم','بوج بده عشقم','بووووووس','دوست دارم','عشقمیییی تو','بوس بوس','فدات بشم من','❤️❤️❤️'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "لینک" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'لینک برای چیته اخه','لینک کجا رو میخوای','لینک گروهو میخوای؟','لینک نداریم برو','میگم نداریم عه','الان دقیقا لینک اینجا رو میخوای؟','لینک برا چیته کلک','باید وایسی مدیر بیاد','خخخ لینک کجا بود'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "اره" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'چی اره؟','مسخره کردیاا','مگه من با تو شوخی دارم','من رباتم چی میخوای از دستم','ولم کن مستر ','نمیدم اصلا','ندارم جون تو','نمییییدیییمم','ول کن برو ندارم'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "کیر" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'بی ادب','بی فرهنگ','بی شعور','خاک بر سرت کنن','احمق بی ادب','فرهنگ داشته باش','به اندازه نخود مغز نداری فوش میدی','بی نزاکت','واقعا خیلی بده کارت به جایی رسیده ربات تحقیرت کنه'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "کس" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'بی ادب','بی فرهنگ','بی شعور','خاک بر سرت کنن','احمق بی ادب','فرهنگ داشته باش','به اندازه نخود مغز نداری فوش میدی','بی نزاکت','واقعا خیلی بده کارت به جایی رسیده ربات تحقیرت کنه'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "کون" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'بی ادب','بی فرهنگ','بی شعور','خاک بر سرت کنن','احمق بی ادب','فرهنگ داشته باش','به اندازه نخود مغز نداری فوش میدی','بی نزاکت','واقعا خیلی بده کارت به جایی رسیده ربات تحقیرت کنه'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "😒" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'هوم؟؟؟','مسخره کردیاا','مگه من با تو شوخی دارم','چته','روانی ','گمجو اصن','برو خونتون','هاااااااااان😒','برو بچه😒'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "نه" then
     if msg.to.type == 'channel' or 'chat' then
            local answers = {'چی نه؟','مسخره کردیاا','چراا نه؟','عجباااا','نه جون من ','تروخدااا','برووو دیگه','آخه چرا نه؟','نه دیگه؟'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "خخخخ" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'خخخخ','خنده داشت؟','بی مزهه','خوشمزه شدی','واییی جووون تو فقط بخند ','عاشق خنده هاتم','خنده هاتو دوست دارم','اوووف تو فقط بخند','عشقم بیا پی وی قربون خنده هات'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "pv" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'pv???','پی وی حرامه','شما بیا پی وی من کارت دارم','یکی هم بیاد پی وی ما','پی وی خز شد اه ','برید پی ویش تا خودشو نکشته','همش پی وی پی وی پس کی تو گروهه','پی وی شکلات میدن انقدر میرید؟','یکی بیاد پی وی من یه آدامس دارم آهنگ میخونه'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "پی وی" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'pv???','پی وی حرامه','شما بیا پی وی من کارت دارم','یکی هم بیاد پی وی ما','پی وی خز شد اه ','برید پی ویش تا خودشو نکشته','همش پی وی پی وی پس کی تو گروهه','پی وی شکلات میدن انقدر میرید؟','یکی بیاد پی وی من یه آدامس دارم آهنگ میخونه'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "پیوی" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'pv???','پی وی حرامه','شما بیا پی وی من کارت دارم','یکی هم بیاد پی وی ما','پی وی خز شد اه ','برید پی ویش تا خودشو نکشته','همش پی وی پی وی پس کی تو گروهه','پی وی شکلات میدن انقدر میرید؟','یکی بیاد پی وی من یه آدامس دارم آهنگ میخونه'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😂" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'😂😂😂','وای دلم😂','شما چقد خوش خنده ای عشقم😂','جوون تو فقط بخند 😂😂','اه بسه دیگه چقد میخندی','یکی اینو ببره تا از خنده غش نکرده😂','اوووف عاشق خنده هاتم😂','جدی بسه😂','خنده هات خیلی زیباست عشقم😂😂','لطقا تمومش کن','دیشب تو دریاچه نکن بودی انگار','بسه دیگه','کافیه برای چی میخندی','مسخره بازیا رو تموم کن','مسخره کردی منو؟'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "به تو چه" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'به من همه چه','چرا اخه😔','دوست دارم بدونم خو','حرف آخرته دیگه؟','چراا اخه نمیگی بم','حالا من شدم غریبه دیگه','باشه نگو','نخواستم اصلا'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "ویس" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'ویس دوس داری عشقم؟','اره اره ویس بفرست میخوام','صداتو عشقه','الان ویس میخوای؟','منم صدام خوبه ها ویس بدم؟','بیا پی ویس ویس بازی کنیم','یه ویس بفرست پی وی','جوون ویس'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "دوست" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'منم دوست دارم','میسی عشقم😍','نفسمی😚','مرسی عزیزم','بیا پی وی رل بزنیم عشقم😍😂','عاشقتم که🙊','شما بیا پی وی کارت دارم😉','مرسی زیبایی زندگیم💐❤️'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😔" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'😔ناراحت نباش','گریه کن خالی شی عشقم','😔گریه نکن اشک درومد','بیا پی وی بت آرامش بدم','نمیای پی وی؟','اوووف هم ناراحتی','ناراحت نشو عزیزم','بیخیال ناراحت نباش'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "سوال" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'سوال بپرسم؟','کلاس چندم عمویی','سوال میکنم جواب میدی؟','سوالت چرت بود','نمیای پی وی؟','مسخره با این سوالات','سوال داری بپرس','اگه بلد باشم جواب میدم'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "جواب" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'جواب بدم؟','حتما باید بگم؟','نمیشه نگم؟','نمیگم','نمیای پی وی؟','جوابت مسخره بوداا','خیلی چرتی خخخ','عجب پاسخی'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "تمام" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'چییییی؟','چی تمام کردی؟','تمام نکن','تو نمیتونی این کارو با من بکنی','چی تمام؟','اوخیی','بمیرم برات','خیلی ناراحت شدم'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "👍" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'👍','لایک به وجودت','لایک داشت','ایول','لایک به خودت گلم','جووونز لایک کرد','بمیری برام خخخ','لایک تقدیم به تو'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "لایک" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'👍','لایک به وجودت','لایک داشت','ایول','لایک به خودت گلم','جووونز لایک کرد','بمیری برام خخخ','لایک تقدیم به تو'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "خبر" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'خبر؟؟','چی شده','عه نگوووو','چه خبره','واقعا؟','خبرا زیاده','تو چه خبر','خبر چی اخه','مگه من اخبارم اخه','به من چه'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "علیرضا" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'وایی عشقم بابام','با بابام کاری داری؟','عشق منهه که','دوست دارم بابایی','بابایی بیا کارت دارن','واییی باباییییی','بوج برای بابام'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😘" then
     if msg.to.type == 'channel' or 'chat' then
           local answers = {'😘😘','اووووف بوسم کرد','واییی تو گروه عشقم نکن','بیا پی وی عشقم','واهاییی','بوسه های زیباتو دوست دارم','بوووووووووووووج'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "بگو" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'نمیگم','چرا بگم','مگه تو کی هستی به حرفت گوش بدم','نمیگم به تو هم ربطی نداره ','تو بگو ببینم بلدی','بگم؟','گمجو نمیگم بت'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "باشه" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'باشه؟','چی باشه','باشه نه لاشه','باوشه بهتره بگی','به من چه ','خیلی خری ','خخخخخ خوب چی باشه'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "ممنون" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'خ����اهش ��یکنم','وظیفست قربان','مرضو ممنون','هههههه ممنون که چی شد حالا گفتی','نیازی به تشکر تو ندارم','خودتو خر کن','خواهش'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "رعایت" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'مگه چراغ قرمزه','مگه پلیسی تو','به تو چه اخه','نمیخوام اصلا رعایت کنیم','مگه چی گفتیم','ادبو رعایت کنیم؟','باشه میکنیم !'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😕" then
     if msg.to.type == 'channel' or 'chat' then
           local answers = {'😕😕','چه مرگته تو','بمیر اصلا','مرسییی اه','گمجو به نظرم','دهنت چرا همیشه کجه تو؟','چته الان دقیقا','مشکلت چیه کسخل'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "خفه شو" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'خودت خفه شو','دلت میاد خفه بشم؟','خیلی بی رحمی','الان دقیقا میخوای چکار کنم؟','نمیشم','حتما بشم؟','تا 3 بشمار خفه بشم','نمیشم کسخل مالیاتی'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "گمشو" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'بی ادب','کجا گم شم؟','آدرسو بلدم گم نمیشم','خودت گمشو','بی شول','به نظرم بگو گمجو خوشمل تره','اگه نرم میخوای چه غلطی بکنی مثلا','چته الان دقیقا','چکارم داری توووو عه'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "سیک" then
     if msg.to.type == 'channel' or 'chat' then
           local answers = {'بی ادب','تیرشو یادت رفت','حضوری بیا بگامت بچه پرو','گمشو بابا جقی','خودت سیک کن کیری فیس','برو جقتو بزن','اگه نرم میخوای چه غلطی بکنی مثلا','چته الان دقیقا','خخخخخ بسیک باو'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "/ids" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'نزن دیگه','نزن هویییییی','هوی کله کیری نزن دیگه','کونت میخواره همش میزنی','سیک کن دیگه نزن اه','نزن کله خمیری','بیا خونمون','بزن تا پاره شی','نزن'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "bk" then
     if msg.to.type == 'channel' or 'chat' then
           local answers = {'bk k bk','mage to kiram dari?','به نخودت نناز خخخخ','بی شرف نفرست','نفرست عوضی','نزن کله خمیری','بیا خونمون','ارسال نکن','بسسسسسسسسسسسهههههههههههههههههههههه'}
            return answers[math.random(#answers)]
      end
    end
end
return {
  description = "Chat With Robot Server", 
  usage = "chat with robot",
  patterns = {
    "^بای$",
	 "^خدافظ$",
	"^خوبی؟$",
	"^خوبی$",
	"^خوبین$",
	"^😐$",
	"^شب بخیر$",
	"اصل",
	"^سلام$",
	"ربات",
	"😍",
	"لینک",
	"اره",
	"کیر",
	"کس",
	"کون",
	"😒",
	"نه",
	"خخخخ",
	"pv",
	"پی وی",
	"پیوی",
	"😂",
	"به تو چه",
	"ویس",
	"دوست",
	"😔",
	"سوال",
	"جواب",
	"تمام",
	"👍",
	"لایک",
	"خبر",
	"😘",
	"بگو",
	"باشه",
	"ممنون",
	"رعایت",
	"😕",
	"خفه شو",
	"گمشو",
	"سیک",
	"/ids",
	"bk",
    }, 
  run = run
}

--by @alireza_PT (@CliApi)
--Our channel: @create_antispam_bot