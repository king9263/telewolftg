function run(msg, matches)
if matches[1] == 'sticker' then
  local openplugins = matches[2]
  local url = "http://api.iteam-co.ir/imgmaker.php?text="..openplugins.."&size=150"
 local ext = ".webp"
  local cb_extra = {file_path=file}
  local receiver = get_receiver(msg)
  local file = download_to_file(url, ".webp")
  send_document(receiver, file, rmtmp_cb, cb_extra)
end
   end
return {
  patterns = {
   "[!#/](sticker) (.*)",
  },
  run = run
}