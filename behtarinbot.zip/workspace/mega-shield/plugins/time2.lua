function run(msg, matches)
local url , res = http.request('http://api.gpmod.ir/time/')
if res ~= 200 then
 return "No connection"
  end
local jdat = json:decode(url)
if matches[1] == 'time' then
  local url = "http://api.iteam-co.ir/imgmaker.php?text="..jdat.ENtime.."&size=150"
 local ext = ".webp"
  local cb_extra = {file_path=file}
  local receiver = get_receiver(msg)
  local file = download_to_file(url, ".webp")
  send_document(receiver, file, rmtmp_cb, cb_extra)
end
   end
return {
  patterns = {
   "[!#/](time)",
  },
  run = run
}
--@openplugins