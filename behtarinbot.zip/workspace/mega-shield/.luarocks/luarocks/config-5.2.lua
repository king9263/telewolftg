rocks_trees = {
   { name = [[system]], root = [[/home/ubuntu/workspace/mega-shield/.luarocks]] }
}
